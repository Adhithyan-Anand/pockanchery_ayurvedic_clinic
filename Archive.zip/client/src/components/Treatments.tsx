import { motion } from "framer-motion";
import RevealWrapper from "./RevealWrapper";

export default function Treatments() {
  const otherTreatments = [
    {
      id: "nasya",
      title: "Nasya (Nasal Administration)",
      description: "This procedure clears the upper respiratory tract and enhances the functioning of sense organs, including vision.",
      image: "https://images.unsplash.com/photo-1615473787506-93442121e89e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80"
    },
    {
      id: "netra-dhara",
      title: "Netra Dhara (Eye Irrigation)",
      description: "Continuous pouring of herbal decoctions over closed eyes to relieve eye strain, dryness, and inflammation.",
      image: "https://images.unsplash.com/photo-1614953566483-448f5377fa89?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80"
    },
    {
      id: "anjana",
      title: "Anjana (Herbal Collyrium)",
      description: "Application of medicated herbal paste or liquid to cleanse the eyes and improve visual acuity.",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80"
    }
  ];

  const netraTarpanaConditions = [
    "Dry Eye Syndrome", "Eye fatigue", "Blurred vision", 
    "Early-stage cataracts", "Computer Vision Syndrome", "Chronic eye allergies"
  ];

  return (
    <section id="treatments" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <RevealWrapper>
            <h2 className="text-3xl font-heading font-bold text-primary mb-2">Specialized Treatments</h2>
          </RevealWrapper>
          <RevealWrapper delay={0.1}>
            <div className="w-20 h-1 bg-accent mx-auto mb-4"></div>
          </RevealWrapper>
          <RevealWrapper delay={0.2}>
            <p className="max-w-3xl mx-auto text-lg">Holistic and natural treatments for a wide range of eye disorders</p>
          </RevealWrapper>
        </div>
        
        {/* Netra Tarpana */}
        <div id="netra-tarpana" className="mb-16">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <RevealWrapper>
                <h3 className="text-2xl font-heading font-semibold text-primary mb-4">
                  Netra Tarpana (Eye Rejuvenation Therapy)
                </h3>
              </RevealWrapper>
              <RevealWrapper delay={0.1}>
                <p className="mb-4">
                  Nethra Tharpanam is a classical Ayurvedic treatment for the eyes. It is a rejuvenating therapy where medicated ghee is gently retained over the eyes for a specific period. This allows deep nourishment of the eye tissues, improves vision, and relieves eye fatigue.
                </p>
              </RevealWrapper>
              
              <RevealWrapper delay={0.2}>
                <div className="mb-4">
                  <h4 className="text-xl font-heading font-medium text-primary mb-2">Why is it Done?</h4>
                  <ul className="grid grid-cols-2 gap-2">
                    {netraTarpanaConditions.map((condition, index) => (
                      <li key={index} className="flex items-start">
                        <svg className="w-5 h-5 text-secondary mt-1 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <span>{condition}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </RevealWrapper>
            </div>
            
            <RevealWrapper>
              <img 
                src="https://images.unsplash.com/photo-1577130740298-839147dbb363?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600&q=80" 
                alt="Netra Tarpana Treatment" 
                className="rounded-lg shadow-lg"
              />
            </RevealWrapper>
          </div>
        </div>
        
        {/* Other Treatments */}
        <div className="grid md:grid-cols-3 gap-8">
          {otherTreatments.map((treatment, index) => (
            <RevealWrapper key={treatment.id} delay={0.1 * index}>
              <div id={treatment.id} className="p-6 bg-white rounded-lg shadow-md hover-grow">
                <div className="overflow-hidden rounded-lg mb-4">
                  <motion.img 
                    src={treatment.image} 
                    alt={treatment.title} 
                    className="w-full h-48 object-cover rounded-lg"
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
                <h3 className="text-xl font-heading font-semibold text-primary mb-2">{treatment.title}</h3>
                <p className="mb-4">{treatment.description}</p>
                <a href="#contact" className="text-secondary hover:text-primary font-medium flex items-center">
                  Learn More
                  <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
                  </svg>
                </a>
              </div>
            </RevealWrapper>
          ))}
        </div>
      </div>
    </section>
  );
}

import { motion } from "framer-motion";
import RevealWrapper from "./RevealWrapper";

export default function Doctors() {
  const doctors = [
    {
      name: "Dr. P.R. SIDHARTHA SANKAR",
      qualifications: "B.A.M, Rtd. Specialist Senior Medical Officer (Netra)",
      specialty: "OPHTHALMOLOGY, ENT AND HEAD & NECK",
      bookingNumbers: [
        { number: "9567077650", time: "7am – 8am" },
        { number: "9446361607", time: "9:30pm – 10:30pm" }
      ],
      image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80"
    },
    {
      name: "Dr. P.S. ADARSH",
      qualifications: "B.A.M.S, MS (Ay) Shalakyatantra",
      specialty: "OPHTHALMOLOGY, ENT AND HEAD & NECK",
      bookingNumbers: [
        { number: "8893434393", time: "9pm – 10pm" }
      ],
      image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80"
    },
    {
      name: "Dr. SREELAKSHMI ADARSH",
      qualifications: "B.A.M.S, MD (Ay) Kayachikitsa",
      specialty: "GENERAL MEDICINE & WOMEN'S HEALTH",
      bookingNumbers: [
        { number: "9061547177", time: "9pm – 10pm" }
      ],
      image: "https://images.unsplash.com/photo-1594824476967-48c8b964273f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <RevealWrapper>
            <h2 className="text-3xl font-heading font-bold text-primary mb-2">Our Specialists</h2>
          </RevealWrapper>
          <RevealWrapper delay={0.1}>
            <div className="w-20 h-1 bg-accent mx-auto mb-4"></div>
          </RevealWrapper>
          <RevealWrapper delay={0.2}>
            <p className="max-w-3xl mx-auto text-lg">Meet our expert doctors with decades of experience</p>
          </RevealWrapper>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {doctors.map((doctor, index) => (
            <RevealWrapper key={index} delay={0.1 * index}>
              <div className="bg-light-green rounded-lg overflow-hidden shadow-md hover-grow">
                <motion.div 
                  className="h-64 overflow-hidden"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.3 }}
                >
                  <img 
                    src={doctor.image} 
                    alt={doctor.name} 
                    className="w-full h-full object-cover"
                  />
                </motion.div>
                <div className="p-6">
                  <h3 className="text-xl font-heading font-semibold text-primary mb-1">{doctor.name}</h3>
                  <p className="text-gray-600 mb-3">{doctor.qualifications}</p>
                  <div className="border-t border-gray-200 pt-4 mt-4">
                    <h4 className="font-medium text-gray-800 mb-2">Speciality</h4>
                    <p className="text-gray-600 mb-4">{doctor.specialty}</p>
                    
                    <h4 className="font-medium text-gray-800 mb-2">Booking</h4>
                    {doctor.bookingNumbers.map((booking, i) => (
                      <p key={i} className="text-gray-600 flex items-center mt-1">
                        <svg className="w-4 h-4 text-primary mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                        </svg>
                        {booking.number} @ {booking.time}
                      </p>
                    ))}
                  </div>
                </div>
              </div>
            </RevealWrapper>
          ))}
        </div>
      </div>
    </section>
  );
}

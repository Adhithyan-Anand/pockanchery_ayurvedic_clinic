import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export default function Logo({ className, size = 'md' }: LogoProps) {
  const sizes = {
    sm: "h-8 w-8",
    md: "h-12 w-12",
    lg: "h-16 w-16"
  };

  return (
    <div className="flex items-center">
      <div className="mr-2">
        <svg 
          viewBox="0 0 80 80" 
          className={cn(sizes[size], "rounded-full", className)}
          fill="#2a7d4f"
        >
          <circle cx="40" cy="40" r="40" fill="#e8f5e9" />
          <path d="M55,25c-8.3,0-15,6.7-15,15c0-8.3-6.7-15-15-15s-15,6.7-15,15c0,8.3,6.7,15,15,15
            c8.3,0,15-6.7,15-15c0,8.3,6.7,15,15,15s15-6.7,15-15C70,31.7,63.3,25,55,25z M25,50c-5.5,0-10-4.5-10-10s4.5-10,10-10
            s10,4.5,10,10S30.5,50,25,50z M55,50c-5.5,0-10-4.5-10-10s4.5-10,10-10s10,4.5,10,10S60.5,50,55,50z" />
          <circle cx="25" cy="40" r="5" fill="#e8f5e9" />
          <circle cx="55" cy="40" r="5" fill="#e8f5e9" />
        </svg>
      </div>
      <div>
        <h1 className="text-lg md:text-xl font-heading font-bold text-primary">Pockanchery</h1>
        <p className="text-xs text-gray-600">Ayurvedic Research Center</p>
      </div>
    </div>
  );
}
